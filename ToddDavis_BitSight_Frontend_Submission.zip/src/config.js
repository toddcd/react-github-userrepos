export default {
    GITHUB_API_ENDPOINT: 'https://api.github.com',
  }